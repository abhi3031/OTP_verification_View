
import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtFirst: UITextField!
    @IBOutlet weak var txtSecond: UITextField!
    @IBOutlet weak var txtThird: UITextField!
    @IBOutlet weak var txtForth: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFirst.becomeFirstResponder()
        txtFirst.transform = CGAffineTransform(translationX: 1, y: 1)
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if !(string == "") {
            textField.text = string
            if textField == txtFirst {
                txtSecond.becomeFirstResponder()
            }
            else if textField == txtSecond {
                txtThird.becomeFirstResponder()
            }
            else if textField == txtThird {
                txtForth.becomeFirstResponder()
            }
            else {
                textField.resignFirstResponder()
            }
            return false
        }
        return true
    }
    @IBAction func SecondTextFieldDidChange(_ sender: UITextField) {
    
        let count = txtSecond.text?.characters.count
        if count! == 0  {
            
            txtFirst.becomeFirstResponder()
        }
    }
    @IBAction func ThirdTextFieldDidChange(_ sender: UITextField) {
    
        let count = txtThird.text?.characters.count
        if count! == 0  {
            
            txtSecond.becomeFirstResponder()
        }
    }
    @IBAction func ForthTextFieldDidChange(_ sender: UITextField) {
    
        let count = txtForth.text?.characters.count
        if count! == 0  {
            
            txtThird.becomeFirstResponder()
        }
    }
    @IBAction func btnSendMessage(_ sender: Any) {
    
        if txtFirst.text != "" && txtSecond.text != "" && txtThird.text != "" && txtForth.text != "" {
            
            let alt = UIAlertController(title: "", message: "Thank You!", preferredStyle: .alert)
            alt.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                
                print("Next")
            }))
            self.present(alt, animated: true, completion: nil)
        }else{
            
            let alt = UIAlertController(title: "", message: "Try again!", preferredStyle: .alert)
            alt.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                
                print("Next")
            }))
            self.present(alt, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

